-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Tempo de geração: 24-Nov-2020 às 19:53
-- Versão do servidor: 10.4.14-MariaDB
-- versão do PHP: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `projeto_ed2`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `bd_projeto`
--

CREATE TABLE `bd_projeto` (
  `id_token` int(11) NOT NULL,
  `temp` float NOT NULL,
  `humidade` float NOT NULL,
  `pressao` float NOT NULL,
  `ultatu` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `bd_projeto`
--

INSERT INTO `bd_projeto` (`id_token`, `temp`, `humidade`, `pressao`, `ultatu`) VALUES
(11111, 56, 22, 33, '2020/01/19'),
(13232, 32, 43, 23, '2020/10/13'),
(123131, 43, 16, 56, '2020/12/23');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tmp_usuario`
--

CREATE TABLE `tmp_usuario` (
  `usuario_id` int(11) NOT NULL,
  `usuario` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `tmp_usuario`
--

INSERT INTO `tmp_usuario` (`usuario_id`, `usuario`) VALUES
(1, 'admin');

-- --------------------------------------------------------

--
-- Estrutura da tabela `token`
--

CREATE TABLE `token` (
  `idtoken` int(11) NOT NULL,
  `nick_token` varchar(45) NOT NULL,
  `usuario_token` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `token`
--

INSERT INTO `token` (`idtoken`, `nick_token`, `usuario_token`) VALUES
(11111, 'arduino1', 1),
(13232, 'ARDUINO 2', 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuario`
--

CREATE TABLE `usuario` (
  `usuario_id` int(11) NOT NULL,
  `usuario` varchar(100) NOT NULL,
  `senha` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `usuario`
--

INSERT INTO `usuario` (`usuario_id`, `usuario`, `senha`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3'),
(2, 'vini', '21232f297a57a5a743894a0e4a801fc3');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `bd_projeto`
--
ALTER TABLE `bd_projeto`
  ADD PRIMARY KEY (`id_token`);

--
-- Índices para tabela `tmp_usuario`
--
ALTER TABLE `tmp_usuario`
  ADD PRIMARY KEY (`usuario_id`);

--
-- Índices para tabela `token`
--
ALTER TABLE `token`
  ADD PRIMARY KEY (`idtoken`,`usuario_token`);

--
-- Índices para tabela `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`usuario_id`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `tmp_usuario`
--
ALTER TABLE `tmp_usuario`
  MODIFY `usuario_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `usuario`
--
ALTER TABLE `usuario`
  MODIFY `usuario_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
